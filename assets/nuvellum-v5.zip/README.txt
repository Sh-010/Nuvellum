NUVELLUM v5.1 — QUICK-CHIP FIX

Fix:
- The hero "Open story" label now lives inside the image as a proper overlay.
- It fades/slides in on hover instead of appearing as stray text above the image.
- It is hidden on touch devices where hover labels are unnecessary.
- No other v5 motion or interaction behavior was changed.
